#!/usr/bin/env expect

# Created by  : Komal Chowdhary
# Created on  : 27.11.2014

### VERSION HISTORY
# Version     : 1.0
# Purpose     : To invoke expect environment from bash script 
# Description : Development and testing of simulations
# Date        : 27 NOV 2014
# Who         : Komal Chowdhary

############################################################
#Switching root user to delete Security Folders TLS and SL3
###########################################################

spawn su root -c "rm -rf /netsim/netsimdir/Security"
expect "Password:"
send "shroot\r"
expect eof

