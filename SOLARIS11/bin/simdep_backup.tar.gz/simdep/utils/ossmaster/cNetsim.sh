#!/bin/sh

# Created by  : Komal Chowdhary
# Created on  : 27.11.2014

### VERSION HISTORY
# Version     : 1.0
# Purpose     : Utility to Clean the Netsim 
# Description : Development and testing of simulations
# Date        : 27 NOV 2014
# Who         : Komal Chowdhary



################################
# MAIN
################################
LOGFILE=/tmp/cleanNetsim.log
PWD=`pwd`
NOW=`date +"%Y_%m_%d_%T:%N"`
MMLSCRIPT=clean.mml

if [ -f $PWD/$MMLSCRIPT ]
then
    rm -r  $PWD/$MMLSCRIPT
    echo "old "$PWD/$MMLSCRIPT" removed"
fi

if [ -f $LOGFILE ]
then
    rm -r  $LOGFILE
    echo "old "$LOGFILE" removed"
fi

echo "... $0 script started running at "`date` | tee -a $LOGFILE
echo "" | tee -a $LOGFILE


#########################################
#
# Make MML Script
#
#########################################

echo ""
echo "MAKING MML SCRIPT"
echo ""
##########################################
#Deleting Ports and Default Destination
###########################################
echo .select configuration >> $MMLSCRIPT

# .config empty command deletes both port and default destination
echo .config empty >> $MMLSCRIPT

echo .config save >> $MMLSCRIPT

##############################################
#Deleting all network Simulations
###############################################
NETSIMDIR=/netsim/netsimdir
SIMULATIONS=`ls -1 $NETSIMDIR/*/simulation.netsimdb | sed -e "s/.simulation.netsimdb//g" -e "s/^[^*]*[*\/]//g" |grep -v -E '^default$'`

#############restart netsim gui incase it is used by some UI####################
echo "<`date '+%X'`>-INFO: Restarting netsim to stop gui and nodes fastly" | tee -a $LOGFILE
echo ""
/netsim/inst/restart_netsim fast


echo "<`date '+%X'`>-INFO: Deleting existing simulation zip files" | tee -a $LOGFILE
echo ""
/bin/rm -vrf /netsim/netsimdir/*.zip | tee -a $LOGFILE

echo "<`date '+%X'`>-INFO: Deleting Netsim Ports and Default Destination" | tee -a $LOGFILE
echo ""
echo "<`date '+%X'`>-INFO: Deleting existing simulations" | tee -a $LOGFILE
echo ""
echo "$SIMULATIONS" | while read sim 
do
    echo ".deletesimulation $sim force" >> $MMLSCRIPT
done

(/netsim/inst/netsim_pipe < $MMLSCRIPT) |  tee -a $LOGFILE

###############################################
#Deleting security folder TLS and SLS
################################################

echo "<`date '+%X'`>-INFO: Deleting security folder TLS and SLS" | tee -a $LOGFILE
./expect_root.sh | tee -a $LOGFILE
echo ""


###############################################
#Restarting The Netsim
#################################################
echo "<`date '+%X'`>-INFO: Restarting netsim for changes to be saved" | tee -a $LOGFILE
echo ""
/netsim/inst/restart_netsim

echo "<`date '+%X'`>-INFO: Starting netsim gui for immediate usage" | tee -a $LOGFILE
echo ""
/netsim/inst/netsim_gui 



#########################
# End of the script
#######################
rm $PWD/$MMLSCRIPT

echo "...$0 script ended at "`date` | tee -a $LOGFILE
echo "" | tee -a $LOGFILE

echo " ***************************************" | tee -a $LOGFILE
echo " *    Netsim is  cleaned    *" | tee -a $LOGFILE
echo " ***************************************" | tee -a $LOGFILE

exit 0

