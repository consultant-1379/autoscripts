#!/usr/bin/perl -w
use Getopt::Long();

###################################################################################
#
#     File Name : fetchFreeIps.pl
#
#     Version : 2.00
#
#     Author : Jigar Shah
#
#     Description : Executes showfreeIPs and gets the IPs
#
#     Date Created : 29 October 2013
#
#     Syntax : ./fetchFreeIps.pl <NumberOfIps>
#
#     Parameters : <ipv4||ipv6> The number of Ips that needs to be fetched
#
#     Example :  ./fetchFreeIps.pl -ipv4=20
#
#     Dependencies : 1. showfreeIPs should be present
#
#     NOTE:
#
#     Return Values : 1 -> Not a netsim user
#		      2 -> Usage is incorrect
#
###################################################################################
#
#----------------------------------------------------------------------------------
#Variables
#----------------------------------------------------------------------------------
$PWD = `pwd`;
chomp($PWD);

#
#----------------------------------------------------------------------------------
#Check if the scrip is executed as netsim user
#----------------------------------------------------------------------------------
#
$user = `whoami`;
chomp($user);
$netsim = 'netsim';
if ( $user ne $netsim ) {
    print "Error: Not netsim user. Please execute the script as netsim user\n";
    exit(1);
}

#
#----------------------------------------------------------------------------------
#Check if the script usage is right
#----------------------------------------------------------------------------------
sub usage {
    my $message = $_[0];
    if ( defined $message && length $message ) {
        $message = "HELP: $message \n"
          unless $message =~ /\n$/;
    }

    my $command = $0;
    $command =~ s#^.*/##;

    print STDERR (
        $message,
        "  usage: $command -ipv4=12 \n"
          . "  usage: $command -ipv6=10 \n"
          . "  usage: $command -ipv4=12  -ipv6=10 \n"
    );

    die("\n");
}

my $numOfIpv4;
my $numOfIpv6;

Getopt::Long::GetOptions(
    'ipv4=i' => \$numOfIpv4,
    'ipv6=i' => \$numOfIpv6,
) or usage("Invalid commmand line options.");

usage("Type and number of ip address must be specified.")
  unless defined $numOfIpv4 || $numOfIpv6;

print "RUNNING: $0 @ARGV \n";


#
#----------------------------------------------------------------------------------
#Environment variable
#----------------------------------------------------------------------------------
#
print "requested-numOfIpv4=$numOfIpv4 \n" if defined $numOfIpv4;
print "requested-numOfIpv6=$numOfIpv6 \n" if defined $numOfIpv6;

my $IPv4_FILE = "$PWD/../dat/free_IpAddr_IPv4.txt";
my $IPv6_FILE = "$PWD/../dat/free_IpAddr_IPv6.txt";

#----------------------------------------------------------------------------------
#Delete existing ipv4 and ipv6 ip files.
#----------------------------------------------------------------------------------

print "INFO: Deleting existing free ip address ipv4-ipv6 files\n";
if ( -e $IPv4_FILE ){
    print `rm -v $IPv4_FILE` . "\n";
}
if ( -e $IPv6_FILE ){
    print `rm -v $IPv6_FILE` , "\n";
}


#----------------------------------------------------------------------------------
#Run the showfreeIPs command and store the location of the fileRGV[0]";
#----------------------------------------------------------------------------------
`$PWD/../utils/checkUsedIps.sh`;

#----------------------------------------------------------------------------------
# IPv4 setup: Currently Vapps have ~1000 available IPv4 addresses
#----------------------------------------------------------------------------------
my @free_IPv4s = ();
if ( defined $numOfIpv4 && $numOfIpv4 != 0 ) {

    open FH1_IPv4, "$PWD/../dat/avail_IpAddr_IPv4.txt";
    @listOfAvailIPv4 = <FH1_IPv4>;
    close(FH1_IPv4);
    open FH2_IPv4, "<$PWD/../dat/used_IpAddr_IPv4.txt";
    @listOfUsedIPv4 = <FH2_IPv4>;
    close(FH2_IPv4);

    $counter = 0;
    foreach my $availIPv4 (@listOfAvailIPv4) {
        $flag = 1;
        foreach $usedIPv4 (@listOfUsedIPv4) {
            if ( $usedIPv4 eq $availIPv4 ) {
                $flag = 0;
                last;
            }
        }
        if ( $flag == 1 ) {
            next if ( $availIPv4 =~ /^#/
                || $availIPv4 =~ /255/ );
            push @free_IPv4s, $availIPv4;
            $counter++;
            print "$counter : freeIPv4=$availIPv4";
            if ( $counter == $numOfIpv4 ) {
                last;
            }
        }
    }

    if ( $counter != $numOfIpv4 ) {
        print
          "ERROR: Requested free ipv4:$numOfIpv4, avail free ipv4:$counter \n";
        exit 1;
    }

    open dumpFreeIPv4s, ">$PWD/../dat/free_IpAddr_IPv4.txt";
    print dumpFreeIPv4s @free_IPv4s;
    close dumpFreeIPv4s;

    print "\n";
}

#----------------------------------------------------------------------------------
# IPv6 setup: Currently Vapps have ~1000 available IPv6 addresses
#----------------------------------------------------------------------------------

my @free_IPv6s = ();
if ( defined $numOfIpv6 && $numOfIpv6 != 0) {

    open FH1_IPv6, "$PWD/../dat/avail_IpAddr_IPv6.txt";
    @listOfAvailIPv6 = <FH1_IPv6>;
    close(FH1_IPv6);
    open FH2_IPv6, "<$PWD/../dat/used_IpAddr_IPv6.txt";
    @listOfUsedIPv6 = <FH2_IPv6>;
    close(FH2_IPv6);

    $counter = 0;
    foreach my $availIPv6 (@listOfAvailIPv6) {
        $flag = 1;
        foreach $usedIPv6 (@listOfUsedIPv6) {
            if ( $usedIPv6 eq $availIPv6 ) {
                $flag = 0;
                last;
            }
        }
        if ( $flag == 1 ) {

           # currently I don't have sufficient info to identify valid ipv6 addrr
           #  for now I am adding all candidate free ipv6 addrs.
           #  subject to change in future when I have sufficient ipv6 knowledge
            push @free_IPv6s, $availIPv6;
            $counter++;
            print "$counter : freeIPv6=$availIPv6";
            if ( $counter == $numOfIpv6 ) {
                last;
            }
        }
    }

    if ( $counter != $numOfIpv6 ) {
        print
          "ERROR: Requested free ipv6:$numOfIpv6, avail free ipv6:$counter \n";
        exit 1;
    }

    open dumpFreeIPv6s, ">$PWD/../dat/free_IpAddr_IPv6.txt";
    print dumpFreeIPv6s @free_IPv6s;
    close dumpFreeIPv6s;
}

