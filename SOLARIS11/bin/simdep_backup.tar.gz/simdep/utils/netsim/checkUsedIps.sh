#!/bin/sh
PWD=`pwd`
#echo ".show allsimnes" | /netsim/inst/netsim_shell | awk -F" " '{print $2}' | sed '/^$/d' | grep -v "[a-z][A-Z]*"  | awk -F":" '{print $1}'| grep -v ":" | sed '/^NE/d' > ../dat/dumpUsedIps_Intermediate.txt

#cat ../dat/dumpUsedIps_Intermediate.txt | awk -F"," '{print $1}'  > ../dat/dumpUsedIps.txt

#cat ../dat/dumpUsedIps_Intermediate.txt | awk -F"," '{print $2}' | sed '/^$/d' >> ../dat/dumpUsedIps.txt


#cat ../dat/dumpUsedIps_Intermediate.txt | awk -F"," '{print $3}' | sed '/^$/d' >> ../dat/dumpUsedIps.txt

#rm ../dat/dumpUsedIps_Intermediate.txt


LIST_OF_IPS=`echo ".show allsimnes" | /netsim/inst/netsim_shell |  awk -F" " '{print $2}'` 

echo "$LIST_OF_IPS" | grep '^[0-9]\{3\}\.' |awk -F":" '{print $1}' | awk -F"," '{for (i=1; i<=NF; i++) print $i}' | sort -ut. -k1,1 -k2,2n -k3,3n -k4,4n > ../dat/used_IpAddr_IPv4.txt

echo "$LIST_OF_IPS" | grep '^[0-9]\{4\}\:' > ../dat/used_IpAddr_IPv6.txt


