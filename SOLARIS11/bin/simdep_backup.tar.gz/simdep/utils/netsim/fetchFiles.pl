#!/usr/bin/perl -w
use Net::FTP;
###################################################################################
#
#     File Name : fetchFiles.pl
#
#     Version : 2.00
#
#     Author : Jigar Shah
#
#     Description : Gets files from storage server, present support is FTP
#
#     Date Created : 29 October 2013
#
#     Syntax : ./fetchFile.pl <filePath>
#
#     Parameters : <filePath> The path on the FTP server where the files are present.
#
#     Example :  ./fetchFiles.pl /sims/CORE/xjigash/simNetDeployer/simulation
#
#     Dependencies : 1. Should be able to access storage device - FTP server.
#
#     NOTE: 1. The module is only enabled to support FTP as a storage device
#
#     Return Values : 1 ->Not a netsim user
#		      2 -> Usage is incorrect
#		      dumpSimNameList.txt -> list of all the simulations fetched
#
###################################################################################
#
#----------------------------------------------------------------------------------
#Check if the scrip is executed as netsim user
#----------------------------------------------------------------------------------
#
$user = `whoami`;
chomp($user);
$netsim = 'netsim';
if ( $user ne $netsim ) {
    print "Error: Not netsim user. Please execute the script as netsim user\n";
    exit(1);
}

#
#----------------------------------------------------------------------------------
#Check if the script usage is right
#----------------------------------------------------------------------------------
$USAGE =
"Usage: $0 <filePath> \nE.g. $0 /sims/CORE/xjigash/simNetDeployer/simulation\n";

# HELP
if ( @ARGV != 1 ) {
    print "Error:\n$USAGE";
    exit(2);
}

#
#----------------------------------------------------------------------------------
#Change path to dir where you want to transfer the files
#----------------------------------------------------------------------------------
$PWD = `pwd`;
chomp($PWD);

#
#----------------------------------------------------------------------------
#SubRoutine to read config file
#----------------------------------------------------------------------------
#
sub readConfig {
    my $path = $_[0];
    print("INFO: Reading config file from $path \n");
    open CONF, "$path" or die;
    my @conf = <CONF>;
    close(CONF);
    foreach (@conf) {
        next if /^#/;
        if ( $_ =~ "FTP_SERVER" ) {
            @ftpNameEdit = split( /=/, $_ );
        }
        elsif ( $_ =~ "FTP_USER" ) {
            @ftpUserEdit = split( /=/, $_ );
        }
        elsif ( $_ =~ "FTP_PASS" ) {
            @ftpPassEdit = split( /=/, $_ );
        }
        elsif ( $_ =~ "FETCH_FROM_FTP" ) {
            @fetchFromFtpEdit = split( /=/, $_ );
        }

    }
    chomp( $ftpNameEdit[1] );
    my $ftpNameVar = $ftpNameEdit[1];
    chomp( $ftpUserEdit[1] );
    my $ftpUserVar = $ftpUserEdit[1];
    chomp( $ftpPassEdit[1] );
    my $ftpPassVar = $ftpPassEdit[1];
    chomp($fetchFromFtpEdit[1] );
    my $fetchFromFtpVar = $fetchFromFtpEdit[1];
    return ( $ftpNameVar, $ftpUserVar, $ftpPassVar,$fetchFromFtpVar);

}

#
#------------------------------------------
#Details of FTP server and the credentials.
#------------------------------------------
#The details are hardcoded into the code. Need a better way to do this
$PWD = `pwd`;
chomp($PWD);
my $confPath = "$PWD/../conf/conf.txt";
( my $ftpHost, my $ftpUser, my $ftpPass, my $fetchfromftp ) = &readConfig($confPath);
if ($fetchfromftp eq "YES" ) {
    $host     = $ftpHost;
    $user     = $ftpUser;
    $password = $ftpPass;
    chdir("/netsim/netsimdir/");

#
#-----------------------------------------------
#Access the FTP server and fetch relevant files.
#-----------------------------------------------
#
    my $index = 0;
    my $f = Net::FTP->new($host) or die "Can't open $host\n";
    $f->login( $user, $password ) or die "Can't log $user in\n";
    my $filePath = "$ARGV[0]";
    $f->cwd($filePath) or die "Error: Can't cwd to $filePath\n";
    @filesToGet = $f->ls;
    foreach my $fileToGet (@filesToGet) {
        $test[$index] = "$fileToGet\n";
        $index++;
        $f->binary;
        $f->get($fileToGet) or die "Error: Failed to get $fileToGet\n";
    }
#
#------------------------------------------------------------------
#List of files transfered
#------------------------------------------------------------------
    open dumpSimNameList, ">$PWD/../dat/listSimulation.txt";
    print dumpSimNameList @test;
    close dumpSimNameList;
}
else {
    my @pathList = split(m%/%, $ARGV[0]);
    my $network = $pathList[0];
    my $testType = $pathList[1];
    my $simVersion = $pathList[2];
    my $ossTrack = $pathList[3];
    my $simStatus = $pathList[4];
    $str = "$PWD/../utils/searchNexusSimNet.pl  $ossTrack $network $testType $simVersion DOWNLOAD  $simStatus" ;
    `$str | tee -a ../logs/runtimLogFetchFiles.txt`;
}

