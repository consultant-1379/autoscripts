#!/usr/bin/perl -w

use strict;
use warnings;

print "..starting to $0\n";

#print "rootproperty = $rootproperty\n";
#print "one = $one \n";
#print "Foo = $Foo \n";

print "..ending to $0\n";
